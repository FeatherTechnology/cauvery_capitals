<?php
// HTTP URL for links and AJAX
$HOSTPATH = "http://".$_SERVER['HTTP_HOST']."/";
define('HOSTPATH', $HOSTPATH);
?>
